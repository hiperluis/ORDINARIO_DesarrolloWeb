const express = require("express");
const router = express.Router();
const { Proveedor } = require("../models");

router.get("/", async (req, res) => {
  const proveedors = await Proveedor.findAll();
  res.json(proveedors);
});

router.get("/:id", async (req, res) => {
  const cliente = await Proveedor.findByPk(req.params.id);
  if (cliente) res.json(cliente);
  else res.status(404).send("Proveedor no encontrado");
});

router.post("/", async (req, res) => {
  const nuevo = await Proveedor.create(req.body);
  res.json(nuevo);
});

router.put("/:id", async (req, res) => {
  const cliente = await Proveedor.findByPk(req.params.id);
  if (cliente) {
    await cliente.update(req.body);
    res.json(cliente);
  } else res.status(404).send("Proveedor no encontrado");
});

router.delete("/:id", async (req, res) => {
  const cliente = await Proveedor.findByPk(req.params.id);
  if (cliente) {
    await cliente.destroy();
    res.send("Proveedor eliminado");
  } else res.status(404).send("Proveedor no encontrado");
});

module.exports = router;
