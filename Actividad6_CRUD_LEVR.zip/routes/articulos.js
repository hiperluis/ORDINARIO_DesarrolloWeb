const express = require("express");
const router = express.Router();
const { Articulo } = require("../models");

router.get("/", async (req, res) => {
  const articulos = await Articulo.findAll();
  res.json(articulos);
});

router.get("/:id", async (req, res) => {
  const cliente = await Articulo.findByPk(req.params.id);
  if (cliente) res.json(cliente);
  else res.status(404).send("Articulo no encontrado");
});

router.post("/", async (req, res) => {
  const nuevo = await Articulo.create(req.body);
  res.json(nuevo);
});

router.put("/:id", async (req, res) => {
  const cliente = await Articulo.findByPk(req.params.id);
  if (cliente) {
    await cliente.update(req.body);
    res.json(cliente);
  } else res.status(404).send("Articulo no encontrado");
});

router.delete("/:id", async (req, res) => {
  const cliente = await Articulo.findByPk(req.params.id);
  if (cliente) {
    await cliente.destroy();
    res.send("Articulo eliminado");
  } else res.status(404).send("Articulo no encontrado");
});

module.exports = router;
