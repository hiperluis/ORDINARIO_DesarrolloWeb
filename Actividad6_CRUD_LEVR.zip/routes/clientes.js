const express = require("express");
const router = express.Router();
const { Cliente } = require("../models");

router.get("/", async (req, res) => {
  const clientes = await Cliente.findAll();
  res.json(clientes);
});

router.get("/:id", async (req, res) => {
  const cliente = await Cliente.findByPk(req.params.id);
  if (cliente) res.json(cliente);
  else res.status(404).send("Cliente no encontrado");
});

router.post("/", async (req, res) => {
  const nuevo = await Cliente.create(req.body);
  res.json(nuevo);
});

router.put("/:id", async (req, res) => {
  const cliente = await Cliente.findByPk(req.params.id);
  if (cliente) {
    await cliente.update(req.body);
    res.json(cliente);
  } else res.status(404).send("Cliente no encontrado");
});

router.delete("/:id", async (req, res) => {
  const cliente = await Cliente.findByPk(req.params.id);
  if (cliente) {
    await cliente.destroy();
    res.send("Cliente eliminado");
  } else res.status(404).send("Cliente no encontrado");
});

module.exports = router;
