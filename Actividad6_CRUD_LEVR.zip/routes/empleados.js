const express = require("express");
const router = express.Router();
const { Empleado } = require("../models");

router.get("/", async (req, res) => {
  const empleados = await Empleado.findAll();
  res.json(empleados);
});

router.get("/:id", async (req, res) => {
  const cliente = await Empleado.findByPk(req.params.id);
  if (cliente) res.json(cliente);
  else res.status(404).send("Empleado no encontrado");
});

router.post("/", async (req, res) => {
  const nuevo = await Empleado.create(req.body);
  res.json(nuevo);
});

router.put("/:id", async (req, res) => {
  const cliente = await Empleado.findByPk(req.params.id);
  if (cliente) {
    await cliente.update(req.body);
    res.json(cliente);
  } else res.status(404).send("Empleado no encontrado");
});

router.delete("/:id", async (req, res) => {
  const cliente = await Empleado.findByPk(req.params.id);
  if (cliente) {
    await cliente.destroy();
    res.send("Empleado eliminado");
  } else res.status(404).send("Empleado no encontrado");
});

module.exports = router;
