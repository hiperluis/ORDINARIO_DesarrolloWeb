const Sequelize = require("sequelize");
const sequelize = require("../config/database");

const Cliente = require("./Cliente")(sequelize, Sequelize.DataTypes);
const Proveedor = require("./Proveedor")(sequelize, Sequelize.DataTypes);
const Articulo = require("./Articulo")(sequelize, Sequelize.DataTypes);
const Empleado = require("./Empleado")(sequelize, Sequelize.DataTypes);

sequelize.sync();

module.exports = {
  sequelize,
  Cliente,
  Proveedor,
  Articulo,
  Empleado
};
