const express = require("express");
const app = express();
const PORT = 3000;

const clienteRoutes = require("./routes/clientes");
const proveedorRoutes = require("./routes/proveedores");
const articuloRoutes = require("./routes/articulos");
const empleadoRoutes = require("./routes/empleados");

app.use(express.json());

app.use("/clientes", clienteRoutes);
app.use("/proveedores", proveedorRoutes);
app.use("/articulos", articuloRoutes);
app.use("/empleados", empleadoRoutes);

app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
